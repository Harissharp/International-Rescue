<?php
/*
Currently affects:
- form.php
*/

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "international_rescue"
?>